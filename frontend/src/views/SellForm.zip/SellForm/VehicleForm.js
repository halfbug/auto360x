import React from 'react';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Fab from '@material-ui/core/Fab';
import AddIcon from '@material-ui/icons/Add';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import InputLabel from '@material-ui/core/InputLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import FormLabel from '@material-ui/core/FormLabel';
import FormGroup from '@material-ui/core/FormGroup';
import Chip from '@material-ui/core/Chip';
import MenuItem from '@material-ui/core/MenuItem';
import Input from '@material-ui/core/Input';
import ButtonBases from './../../components/ButtonBasses'




const useStyles = makeStyles(theme => ({
  fab: {
    margin: theme.spacing(1),
  },
  extendedIcon: {
    marginRight: theme.spacing(1),
  },
  button: {
    margin: theme.spacing(1),
  },
  input: {
    display: 'none',
  },
   chips: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  chip: {
    margin: 2,
  },
}));

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};
const featurez = [
  'Rearview Camera Sys',
  'Power Driver Seat',
  'Power Liftgate',
  'Navigation System',
  'Omar Alexander',
  'Carlos Abbott',
  'Miriam Wagner',
  'Bradley Wilkerson',
  'Virginia Andrews',
  'Kelly Snyder',
];


export default function VehicleForm(props) { 
  const classes = useStyles();
  const [values,setvalues] = React.useState({});
  const [lfeatures,setlfeatures] = React.useState([]);



  const handleChange = (e) => {
    console.log(e.target)
    if (e.target.files && true){
      console.log(e.target.files)
      const image = e.target.files[0]
      console.log(image)
      setvalues({
      ...values,
      [e.target.id]: image
      });
    }
    if(e.target.name === "features"){
    setlfeatures(e.target.value);
    setvalues({
      ...values,
      [e.target.name]: e.target.value
    });
    }
    else
    setvalues({
      ...values,
      [e.target.id]: e.target.value
    });


    console.log(values)
    
    props.saveAdvertHof({values})
  };

  function handleChangeMultiple(event) {
    const { options } = event.target;
    const value = [];
    for (let i = 0, l = options.length; i < l; i += 1) {
      if (options[i].selected) {
        value.push(options[i].value);
      }
    }
    setlfeatures(value);
  }

  const rare = React.useRef(null);
  const front = React.useRef(null);
   const side = React.useRef(null);
  const interior = React.useRef(null);
  const onButtonClick = (ref) => {
    console.log("inside")
    // `current` points to the mounted text input element
    ref.current.click();
  };

  return (
    <React.Fragment>
      <Typography variant="h6" gutterBottom>
        Vehicle Details
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} >
          <TextField  onChange={handleChange} 
            required
            id="make"
            name="make"
            label="Make"
            fullWidth
            autoComplete="make"
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField onChange={handleChange} 
            required
            id="model"
            name="model"
            label="Model"
            fullWidth
            autoComplete="model"
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField onChange={handleChange} 
            required
            id="Year"
            name="Year"
            label="Year"
            fullWidth
            autoComplete="license"
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField onChange={handleChange} 
            id="trim"
            name="trim"
            label="Trim"
            fullWidth
            autoComplete="trim"
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField onChange={handleChange} 
            required
            id="transmission"
            name="transmission"
            label="Transmission"
            fullWidth
           
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField onChange={handleChange}  id="engine" name="engine" 
          label="Engine Type" 
          fullWidth />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField onChange={handleChange} 
            required
            id="mileage"
            name="mileage"
            label="Mileage (KM)"
            fullWidth
            
          />
        </Grid>
        <Grid item xs={12} sm={12}>
          
          <FormControl className={classes.formControl}  fullWidth>
        <InputLabel htmlFor="style">Style</InputLabel>
        <Select
          native
          value={values.style}
          onChange={handleChange}
          inputProps={{
            name: 'style',
            id: 'style',
          }}
         
        >
          <option value="" />
          <option value="car">Car</option>
          <option value="suv">SUV</option>
          <option value="truck">Truck</option>
          <option value="van">Van</option>
          <option value="coupe">Coupe</option>
          <option value="convertible">Convertible</option>
          <option value="hatchback">Hatchback</option>
          <option value="wagon">Wagon</option>
        </Select>
      </FormControl>


        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField onChange={handleChange} 
            required
            id="exterior_color"
            name="exterior_color"
            label="Exterior Color"
            fullWidth
            
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField onChange={handleChange} 
            required
            id="interior_color"
            name="interior_color"
            label="Interior Color"
            fullWidth
            
          />
        </Grid>
        <Grid item xs={12} sm={12}>
        <FormControl className={classes.formControl} fullWidth>
        <InputLabel htmlFor="features">More Features</InputLabel>
        <Select
          multiple
          name="features"
          id="features"
          value={lfeatures}
          onChange={handleChange}
          input={<Input id="features" />}
          renderValue={selected => (
            <div className={classes.chips}>
              {selected.map(value => (
                <Chip key={value} label={value} className={classes.chip} />
              ))}
            </div>
          )}
          MenuProps={MenuProps}
        >
          {featurez.map(name => (
            <MenuItem key={name} value={name} >
              {name}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
        </Grid>
        <Grid item xs={12}>
           <Typography
              component="h4"
              variant="subtitle1"
              color="inherit"
             
            >
              Upload Photos
            </Typography>
        </Grid>
        <Grid item xs={12} sm={6}>
       
          <input
        accept="image/*"
        className={classes.input}
        id="front_view"
        multiple
        type="file"
        ref={front}
        onChange={handleChange}
      />
      <label htmlFor="fornt_view">
       
        <ButtonBases title ="Front View"
        onClick={()=>onButtonClick(front)}
        />
      </label>


        </Grid>
        <Grid item xs={12} sm={6}>
         <input
        accept="image/*"
        className={classes.input}
        id="rare_view"
        multiple
        type="file"
        ref={rare}
        onChange={handleChange}
      />
      <label htmlFor="rare_view">
        {/* <Button variant="outlined" component="span" className={classes.button}>
          <AddIcon />
        </Button> */}
        <ButtonBases
        onClick={()=>onButtonClick(rare)}
        title ="Rare View"
        />
      </label>


        </Grid>

      {/* side view */}
      <Grid item xs={12} sm={6}>
         <input
        accept="image/*"
        className={classes.input}
        id="side_view"
        multiple
        type="file"
        ref={side}
        onChange={handleChange}
      />
      <label htmlFor="side_view">
        {/* <Button variant="outlined" component="span" className={classes.button}>
          <AddIcon />
        </Button> */}
        <ButtonBases
        onClick={()=>onButtonClick(side)}
        title ="Side View"
        />
      </label>


        </Grid>
        {/* interior view */}
        <Grid item xs={12} sm={6}>
         <input
        accept="image/*"
        className={classes.input}
        id="interior_view"
        multiple
        type="file"
        ref={interior}
        onChange={handleChange}
      />
      <label htmlFor="interior_view">
        {/* <Button variant="outlined" component="span" className={classes.button}>
          <AddIcon />
        </Button> */}
        <ButtonBases
        onClick={()=>onButtonClick(interior)}
        title ="Interior View"
        />
      </label>


        </Grid>
        {/* <Grid item xs={12}>
          <FormControlLabel
            control={<Checkbox color="secondary" name="saveAddress" value="yes" />}
            label="Use this address for payment details"
          />
        </Grid> */}
      </Grid>
    </React.Fragment>
  );
}
